// src/screens/WalletBalanceScreen.js
//
// Read-only balance display — pulls INAYA/USDT/tBNB balances for the
// connected wallet. No signing happens here; this screen only ever reads.

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { useAccount, useProvider } from '@reown/appkit-react-native';
import { ethers } from 'ethers';

const INAYA_TOKEN_ADDRESS = '0x3966a3378c8d9e6bb34dd0b8458eef4b878ce94e';
const USDT_TOKEN_ADDRESS = '0x6f16E2d169B5F2c7141c2b46dD864f8daE01745D';
const ERC20_BALANCE_ABI = ['function balanceOf(address) view returns (uint256)', 'function decimals() view returns (uint8)'];

export default function WalletBalanceScreen() {
  const { address, isConnected } = useAccount();
  const { provider: walletProvider } = useProvider(); // raw EIP-1155 provider for the active connection
  const [balances, setBalances] = useState({ bnb: null, inaya: null, usdt: null });
  const [refreshing, setRefreshing] = useState(false);

  const fetchBalances = async () => {
    if (!isConnected || !address || !walletProvider) return;
    setRefreshing(true);
    try {
      const provider = new ethers.BrowserProvider(walletProvider);
      const [bnbWei, inaya, usdt] = await Promise.all([
        provider.getBalance(address),
        new ethers.Contract(INAYA_TOKEN_ADDRESS, ERC20_BALANCE_ABI, provider).balanceOf(address),
        new ethers.Contract(USDT_TOKEN_ADDRESS, ERC20_BALANCE_ABI, provider).balanceOf(address),
      ]);
      setBalances({
        bnb: parseFloat(ethers.formatEther(bnbWei)).toFixed(4),
        inaya: parseFloat(ethers.formatUnits(inaya, 18)).toFixed(2),
        usdt: parseFloat(ethers.formatUnits(usdt, 18)).toFixed(2),
      });
    } catch (err) {
      console.error('Balance fetch failed:', err);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchBalances(); }, [isConnected, address]);

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={fetchBalances} tintColor="#22d3d0" />}
    >
      <Text style={styles.title}>Wallet Balance</Text>
      <Text style={styles.subtitle}>Read-only — no signing happens on this screen.</Text>

      {!isConnected ? (
        <View style={styles.card}>
          <Text style={styles.cardSub}>Connect a wallet from the Storage Dashboard to see balances here.</Text>
        </View>
      ) : (
        <>
          <BalanceRow label="tBNB (gas)" value={balances.bnb} />
          <BalanceRow label="INAYA" value={balances.inaya} />
          <BalanceRow label="mUSDT" value={balances.usdt} />
        </>
      )}
    </ScrollView>
  );
}

function BalanceRow({ label, value }) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardLabel}>{label.toUpperCase()}</Text>
      <Text style={styles.cardValue}>{value ?? '—'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0a0e14' },
  content: { padding: 20, paddingBottom: 40 },
  title: { fontSize: 24, fontWeight: '800', color: '#fff', marginTop: 8 },
  subtitle: { fontSize: 13, color: '#94a3b8', marginTop: 4, marginBottom: 20 },
  card: { backgroundColor: '#111c33', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#1c2a38', marginBottom: 12 },
  cardLabel: { fontSize: 10, color: '#22d3d0', fontWeight: '700', letterSpacing: 1.5 },
  cardValue: { fontSize: 22, color: '#fff', fontWeight: '800', marginTop: 6 },
  cardSub: { fontSize: 12, color: '#64748b', lineHeight: 18 },
});