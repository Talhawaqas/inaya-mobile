// src/screens/StorageDashboardScreen.js
//
// Home screen — mirrors the web dApp's "Network Home" + Dashboard blend:
// connection state, quick stats, and the entry point into uploading a file
// (the actual encrypt/shard/upload flow lands in Phase 2).

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useWallet } from '../providers/WalletProvider';

export default function StorageDashboardScreen({ navigation }) {
  const { connect, address, isConnected, chainId, connecting } = useWallet();

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Sovereign Data Storage</Text>
      <Text style={styles.subtitle}>Encrypted client-side. Split before it leaves your device.</Text>

      <View style={styles.card}>
        <Text style={styles.cardLabel}>WALLET STATUS</Text>
        {isConnected ? (
          <>
            <Text style={styles.cardValue}>{address?.slice(0, 6)}...{address?.slice(-4)}</Text>
            <Text style={styles.cardSub}>
              {chainId === 97 ? 'BNB Chain Testnet ✓' : `Wrong network (chain ${chainId}) — switch to BNB Testnet`}
            </Text>
          </>
        ) : (
          <TouchableOpacity style={styles.connectButton} onPress={connect} disabled={connecting}>
            <Text style={styles.connectButtonText}>{connecting ? 'Connecting...' : 'Connect Wallet'}</Text>
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.row}>
        <View style={[styles.statCard, { marginRight: 8 }]}>
          <Text style={styles.statBig}>—</Text>
          <Text style={styles.statLabel}>Files Stored</Text>
        </View>
        <View style={[styles.statCard, { marginLeft: 8 }]}>
          <Text style={styles.statBig}>—</Text>
          <Text style={styles.statLabel}>Watcher Uptime</Text>
        </View>
      </View>

      <TouchableOpacity
        style={[styles.actionButton, !isConnected && styles.actionButtonDisabled]}
        disabled={!isConnected}
        onPress={() => { /* Phase 2: file picker + encrypt/shard/upload flow */ }}
      >
        <Text style={styles.actionButtonText}>+ Upload a File</Text>
      </TouchableOpacity>

      <View style={styles.navRow}>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('NodeStatus')}>
          <Text style={styles.navButtonText}>Watcher Node →</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('WalletBalance')}>
          <Text style={styles.navButtonText}>Wallet Balance →</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0a0e14' },
  content: { padding: 20, paddingBottom: 40 },
  title: { fontSize: 26, fontWeight: '800', color: '#fff', marginTop: 8 },
  subtitle: { fontSize: 13, color: '#94a3b8', marginTop: 4, marginBottom: 20 },
  card: { backgroundColor: '#111c33', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#1c2a38', marginBottom: 16 },
  cardLabel: { fontSize: 10, color: '#22d3d0', fontWeight: '700', letterSpacing: 1.5 },
  cardValue: { fontSize: 18, color: '#fff', fontWeight: '700', marginTop: 6 },
  cardSub: { fontSize: 11, color: '#64748b', marginTop: 4 },
  connectButton: { backgroundColor: '#22d3d0', borderRadius: 10, paddingVertical: 12, alignItems: 'center', marginTop: 10 },
  connectButtonText: { color: '#0a0e14', fontWeight: '800', fontSize: 13 },
  row: { flexDirection: 'row', marginBottom: 16 },
  statCard: { flex: 1, backgroundColor: '#111c33', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#1c2a38', alignItems: 'center' },
  statBig: { fontSize: 24, color: '#fff', fontWeight: '800' },
  statLabel: { fontSize: 10, color: '#64748b', marginTop: 4 },
  actionButton: { backgroundColor: '#fff', borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginBottom: 20 },
  actionButtonDisabled: { opacity: 0.4 },
  actionButtonText: { color: '#0a0e14', fontWeight: '800', fontSize: 13 },
  navRow: { flexDirection: 'row', justifyContent: 'space-between' },
  navButton: { paddingVertical: 8 },
  navButtonText: { color: '#22d3d0', fontWeight: '700', fontSize: 13 },
});