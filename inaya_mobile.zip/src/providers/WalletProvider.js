// src/providers/WalletProvider.js
//
// Configures Reown AppKit (formerly "WalletConnect Web3Modal" — that
// package was deprecated Feb 2025, this is its official replacement)
// for BNB Chain Testnet. This is what lets a user tap "Connect Wallet"
// and get a real handshake with MetaMask/Trust Wallet/Binance Web3 Wallet
// via WalletConnect v2 — no seed phrase ever touches this app, matching
// the SOW's non-custodial requirement: this app never sees a private
// key, only ever requests signatures through the connected wallet.

import '@walletconnect/react-native-compat'; // MUST be the very first import, before anything else touches AppKit

import React from 'react';
import { createAppKit, AppKitProvider, AppKit } from '@reown/appkit-react-native';
import { EthersAdapter } from '@reown/appkit-ethers-react-native';

// Get a free project ID at https://dashboard.reown.com — required by
// WalletConnect v2 for rate-limiting/abuse prevention, not a paid service.
const WALLETCONNECT_PROJECT_ID = process.env.EXPO_PUBLIC_WALLETCONNECT_PROJECT_ID;

// BNB Chain Testnet isn't one of viem's commonly-imported chains in every
// version, so it's defined explicitly here to avoid depending on that.
const BNB_TESTNET = {
  id: 97,
  name: 'BNB Smart Chain Testnet',
  nativeCurrency: { name: 'tBNB', symbol: 'tBNB', decimals: 18 },
  rpcUrls: {
    default: { http: ['https://data-seed-prebsc-1-s1.binance.org:8545'] },
  },
  blockExplorers: {
    default: { name: 'BscScan Testnet', url: 'https://testnet.bscscan.com' },
  },
  testnet: true,
};

const ethersAdapter = new EthersAdapter();

export const appKit = createAppKit({
  projectId: WALLETCONNECT_PROJECT_ID,
  networks: [BNB_TESTNET],
  defaultNetwork: BNB_TESTNET,
  adapters: [ethersAdapter],
  metadata: {
    name: 'Inaya Network',
    description: 'Sovereign Data Storage, Settled On-Chain',
    url: 'https://inayanetwork.com',
    icons: ['https://inayanetwork.com/icon.png'],
    redirect: {
      native: 'inayanetwork://',
    },
  },
});

/**
 * Wrap your app's root component with this. The actual "Connect Wallet"
 * button lives wherever you want it — just call useAppKit().open() from
 * any screen; this component only needs to exist once, near the root.
 */
export function WalletProviderRoot({ children }) {
  return (
    <AppKitProvider instance={appKit}>
      {children}
      <AppKit />
    </AppKitProvider>
  );
}