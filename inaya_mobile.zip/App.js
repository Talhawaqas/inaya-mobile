// App.js
//
// Root entry point — sets up navigation between the three Phase 1
// screens and wraps everything in the WalletConnect provider.

import 'react-native-get-random-values'; // must be imported before ethers/crypto anywhere
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';

import { WalletProviderRoot } from './src/providers/WalletProvider';
import StorageDashboardScreen from './src/screens/StorageDashboardScreen';
import NodeStatusScreen from './src/screens/NodeStatusScreen';
import WalletBalanceScreen from './src/screens/WalletBalanceScreen';

const Stack = createNativeStackNavigator();

const navTheme = {
  dark: true,
  colors: {
    primary: '#22d3d0',
    background: '#0a0e14',
    card: '#0e1830',
    text: '#ffffff',
    border: '#1c2a38',
    notification: '#c9a24d',
  },
};

export default function App() {
  return (
    <WalletProviderRoot>
      <NavigationContainer theme={navTheme}>
        <StatusBar style="light" />
        <Stack.Navigator
          initialRouteName="StorageDashboard"
          screenOptions={{
            headerStyle: { backgroundColor: '#0a0e14' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: '800' },
          }}
        >
          <Stack.Screen
            name="StorageDashboard"
            component={StorageDashboardScreen}
            options={{ title: 'Storage Dashboard' }}
          />
          <Stack.Screen
            name="NodeStatus"
            component={NodeStatusScreen}
            options={{ title: 'Watcher Node Status' }}
          />
          <Stack.Screen
            name="WalletBalance"
            component={WalletBalanceScreen}
            options={{ title: 'Wallet Balance' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </WalletProviderRoot>
  );
}